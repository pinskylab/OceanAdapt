# Process GFSPCY.CODE.txt and output as a csv

setwd('/Users/mpinsky/Documents/Princeton/Trawl Data/DFO Newfoundland/Tables')

indata = readLines('GFSPCY.CODE 2012-07-05.txt')

n = numeric(length(indata)); ch = numeric(length(indata))
data = data.frame(sppcode = n, common = ch, spp= ch) # to hold the data

length(indata)
for(j in 1:length(indata)){ # interpret each line
	print(j)
	data$sppcode[j] = as.numeric(substr(indata[j], 5,8))
	data$common[j] = substr(indata[j], 9,32)
	data$spp[j] = substr(indata[j], 33,80)
}

# trim trailing white space
data$common = gsub('[ ]+$', '', data$common)
data$spp = gsub('[ ]+$', '', data$spp)

# checks
i = which(is.na(data$sppcode))
	data[i,]
i = which(is.na(data$common))
	data[i,]
i = which(is.na(data$spp))
	data[i,]

head(data)

# write out csv
write.csv(data, paste('GFSPCY.CODE_', Sys.Date(), '.csv', sep=''))
